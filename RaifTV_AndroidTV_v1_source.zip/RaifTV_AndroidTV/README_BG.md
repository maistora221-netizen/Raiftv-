# RaifTV за Xiaomi Android TV — стартов проект 1.0

## Какво прави тази версия
- Показва собствено меню на цял екран с тъмен дизайн и червени акценти.
- Има големи бутони за Plex, Filmzie и YouTube.
- Стартира вече инсталираните официални приложения.
- Ако приложение липсва, показва съобщение.
- Бутонът „Още приложения“ отваря търсене в Google Play.

## Изисквания
- Компютър с Windows, macOS или Linux.
- Android Studio (безплатно): https://developer.android.com/studio
- Android SDK 35 и JDK 17 (Android Studio може да ги управлява).

## Отваряне и изграждане
1. Разархивирай ZIP файла.
2. Отвори Android Studio → Open и избери папката `RaifTV_AndroidTV`.
3. Изчакай Gradle Sync да приключи. При поискване инсталирай Android SDK 35.
4. Избери Build → Build Bundle(s) / APK(s) → Build APK(s).
5. APK файлът ще бъде в `app/build/outputs/apk/debug/app-debug.apk`.

## Инсталиране на Xiaomi TV
- Активирай Developer options и USB debugging в настройките на телевизора.
- Свържи телевизора и компютъра в една мрежа или чрез USB, ако моделът го поддържа.
- Инсталирай APK чрез Android Studio или ADB:
  `adb install -r app/build/outputs/apk/debug/app-debug.apk`

## Идентификатори на приложения
- Plex: `com.plexapp.android`
- Filmzie: `com.filmzie.platform`
- YouTube Android TV: `com.google.android.youtube.tv`

Ако дадено приложение не е налично в региона/модела на телевизора, RaifTV ще покаже съобщение. Самият RaifTV не включва филми и не заобикаля абонаменти или регионални ограничения.

## Важно
Това е стартов изходен проект, не готов APK и не е тестван на конкретния Xiaomi модел. За първото изграждане е нужен компютър с Android Studio. Следващите подобрения могат да добавят проверка на инсталираните приложения, настройки и редактиране на любимите бутони.
