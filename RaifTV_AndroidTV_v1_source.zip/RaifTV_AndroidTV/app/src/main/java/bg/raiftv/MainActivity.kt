package bg.raiftv

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val backgroundColor = Color.rgb(12, 13, 17)
    private val panelColor = Color.rgb(27, 29, 36)
    private val accentColor = Color.rgb(220, 35, 45)
    private val mutedColor = Color.rgb(170, 174, 185)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = backgroundColor
        window.navigationBarColor = backgroundColor
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LOW_PROFILE
        buildScreen()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(42), dp(28), dp(42), dp(24))
            setBackgroundColor(backgroundColor)
            isFocusableInTouchMode = true
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val logo = TextView(this).apply {
            text = "R"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(accentColor, 14)
            layoutParams = LinearLayout.LayoutParams(dp(54), dp(54))
        }
        header.addView(logo)

        val brand = TextView(this).apply {
            text = "  RaifTV"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        header.addView(brand)

        val free = TextView(this).apply {
            text = "БЕЗПЛАТЕН ФИЛМОВ ЦЕНТЪР"
            textSize = 13f
            setTextColor(accentColor)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
        }
        header.addView(free, LinearLayout.LayoutParams(0, dp(54), 1f))
        page.addView(header)

        val title = TextView(this).apply {
            text = "Какво ще гледаме днес?"
            textSize = 28f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(30), 0, dp(5))
        }
        page.addView(title)

        val subtitle = TextView(this).apply {
            text = "ФИЛМИ  •  СЕРИАЛИ  •  ВИДЕО"
            textSize = 13f
            setTextColor(mutedColor)
            setPadding(0, 0, 0, dp(22))
        }
        page.addView(subtitle)

        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(14), 0, 0)
        }

        row1.addView(serviceButton("PLEX", "Филми и сериали", Color.rgb(45, 54, 72)) {
            launchApp("com.plexapp.android", "Plex")
        }, weightedParams())
        row1.addView(serviceButton("FILMZIE", "Безплатно кино", Color.rgb(35, 91, 67)) {
            launchApp("com.filmzie.platform", "Filmzie")
        }, weightedParams())

        row2.addView(serviceButton("YouTube", "Филми и видео", Color.rgb(150, 31, 37)) {
            launchApp("com.google.android.youtube.tv", "YouTube")
        }, weightedParams())
        row2.addView(serviceButton("ОЩЕ ПРИЛОЖЕНИЯ", "Други безплатни услуги", Color.rgb(66, 47, 53)) {
            openMoreApps()
        }, weightedParams())

        grid.addView(row1)
        grid.addView(row2)
        page.addView(grid)

        val footer = TextView(this).apply {
            text = "МОИТЕ ПРИЛОЖЕНИЯ     •     НАСТРОЙКИ"
            textSize = 13f
            setTextColor(mutedColor)
            gravity = Gravity.CENTER
            background = rounded(panelColor, 14)
            setPadding(dp(16), dp(17), dp(16), dp(17))
        }
        val footerParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(20) }
        page.addView(footer, footerParams)

        val note = TextView(this).apply {
            text = "RaifTV отваря официалните приложения. Наличността им зависи от телевизора и региона."
            textSize = 11f
            setTextColor(mutedColor)
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, 0)
        }
        page.addView(note)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(page)
        }
        setContentView(scroll)
        page.requestFocus()
    }

    private fun serviceButton(
        heading: String,
        description: String,
        color: Int,
        action: () -> Unit
    ): Button {
        return Button(this).apply {
            text = "$heading\n$description"
            textSize = 19f
            isAllCaps = false
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            minHeight = dp(112)
            setPadding(dp(14), dp(16), dp(14), dp(16))
            background = focusBackground(color)
            isFocusable = true
            isFocusableInTouchMode = true
            setOnClickListener { action() }
        }
    }

    private fun launchApp(packageName: String, appName: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            try {
                startActivity(launchIntent)
            } catch (_: ActivityNotFoundException) {
                showNotInstalled(appName)
            }
        } else {
            showNotInstalled(appName)
        }
    }

    private fun showNotInstalled(appName: String) {
        Toast.makeText(
            this,
            "$appName не е открито. Инсталирай го от Google Play на телевизора.",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun openMoreApps() {
        val marketIntent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("market://search?q=free%20movies%20Android%20TV&c=apps")
        )
        try {
            startActivity(marketIntent)
        } catch (_: ActivityNotFoundException) {
            val webIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://play.google.com/store/search?q=free%20movies%20Android%20TV&c=apps")
            )
            startActivity(webIntent)
        }
    }

    private fun weightedParams(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, dp(130), 1f).apply {
            marginEnd = dp(12)
        }

    private fun focusBackground(normalColor: Int) =
        android.graphics.drawable.StateListDrawable().apply {
            addState(
                intArrayOf(android.R.attr.state_focused),
                rounded(Color.rgb(185, 25, 36), 18, Color.WHITE, dp(3))
            )
            addState(
                intArrayOf(android.R.attr.state_pressed),
                rounded(Color.rgb(120, 20, 28), 18)
            )
            addState(
                intArrayOf(),
                rounded(normalColor, 18)
            )
        }

    private fun rounded(
        color: Int,
        radius: Int,
        strokeColor: Int? = null,
        strokeWidth: Int = 0
    ) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (strokeColor != null) setStroke(strokeWidth, strokeColor)
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
